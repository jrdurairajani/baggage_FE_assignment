import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { AppRoutingModule } from './app-routing.module';
import { CalendarModule } from 'primeng/calendar';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonModule } from 'primeng/button';
import { MissingBaggageComponent } from './components/missing-baggage.component';
import { BaggageService } from './services/baggage.service'
import { HttpClientModule } from '@angular/common/http';
import { JourneyDateComponent } from './components/journey-date/journey-date.component';
import { JourneyPlaceComponent } from './components/journey-place/journey-place.component';
import { LostBaggageComponent } from './components/lost-baggage/lost-baggage.component';
import { DropdownModule } from 'primeng/dropdown';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CommonModule } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { TableModule } from 'primeng/table';
import { CardModule } from 'primeng/card';
@NgModule({
  declarations: [
    AppComponent,
    MissingBaggageComponent,
    JourneyDateComponent,
    JourneyPlaceComponent,
    LostBaggageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CalendarModule,
    FormsModule,
    BrowserAnimationsModule,
    ButtonModule,
    AutoCompleteModule,
    HttpClientModule,
    DropdownModule,
    ReactiveFormsModule,
    InputTextModule,
    CommonModule,
    DialogModule,
    TableModule,
    CardModule
  ],
  providers: [BaggageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
