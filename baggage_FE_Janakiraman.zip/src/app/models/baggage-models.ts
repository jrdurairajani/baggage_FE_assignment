export interface Countries {
  id: number;
  name: string;
  country: string;
}

export interface NumberList {
  label: string;
  value: number;
}

export interface Baggage {
  name: string;
  quantity: number;
  price: number
}
