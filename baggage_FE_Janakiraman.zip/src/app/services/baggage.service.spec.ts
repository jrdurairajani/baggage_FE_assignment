import { TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { BaggageService } from './baggage.service';

describe('BaggageService', () => {
  let service: BaggageService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [BaggageService],
    });
    service = TestBed.inject(BaggageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch countries', () => {
    const mockCountries = [
      {
        id: 1,
        name: 'USA',
        country: 'USA',
      },
      {
        id: 2,
        name: 'Canada',
        country: 'CA',
      },
      {
        id: 3,
        name: 'Egypt',
        country: 'EG',
      },
      {
        id: 4,
        name: 'France',
        country: 'FR',
      },
      {
        id: 5,
        name: 'India',
        country: 'IN',
      },
      {
        id: 6,
        name: 'China',
        country: 'CN',
      },
      {
        id: 7,
        name: 'Japan',
        country: 'JP',
      },
    ];

    service.getCountries().subscribe((countries) => {
      expect(countries).toEqual(mockCountries);
    });
  });

  it('should fetch countries', () => {
    const mockItems = [
      { label: '1', value: 1 },
      { label: '2', value: 2 },
      { label: '3', value: 3 },
    ];

    service.getItems().subscribe((items) => {
      expect(items).toEqual(mockItems);
    });
  });
});
