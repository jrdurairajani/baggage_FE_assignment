import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Countries, NumberList } from '../models/baggage-models';

@Injectable({
  providedIn: 'root',
})
export class BaggageService {
  constructor(private http: HttpClient) {}

  public getCountries(): Observable<Countries[]> {
    const url = [
      {
        id: 1,
        name: 'USA',
        country: 'USA',
      },
      {
        id: 2,
        name: 'Canada',
        country: 'CA',
      },
      {
        id: 3,
        name: 'Egypt',
        country: 'EG',
      },
      {
        id: 4,
        name: 'France',
        country: 'FR',
      },
      {
        id: 5,
        name: 'India',
        country: 'IN',
      },
      {
        id: 6,
        name: 'China',
        country: 'CN',
      },
      {
        id: 7,
        name: 'Japan',
        country: 'JP',
      },
    ];
    return of(url);
  }

  public getItems(): Observable<NumberList[]> {
    const url = [
      { label: '1', value: 1 },
      { label: '2', value: 2 },
      { label: '3', value: 3 },
    ];
    return of(url);
  }
}
