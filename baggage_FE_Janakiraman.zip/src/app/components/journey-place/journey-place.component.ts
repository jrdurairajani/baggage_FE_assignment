import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Subscription } from 'rxjs';
import { Countries } from 'src/app/models/baggage-models';
import { BaggageService } from 'src/app/services/baggage.service';

interface AutoCompleteCompleteEvent {
  originalEvent: Event;
  query: string;
}

@Component({
  selector: 'journey-place',
  templateUrl: './journey-place.component.html',
  styleUrls: ['./journey-place.component.css'],
})
export class JourneyPlaceComponent implements OnInit {
  @Output() public emitOriginCountry = new EventEmitter<Countries>();
  @Output() public emitdestinateCountry = new EventEmitter<Countries>();
  public countries!: any[];
  public originCountry!: Countries;
  public destinateCountry!: Countries;
  public filteredCountries: any[] = [];
  private subscriptions: Subscription = new Subscription();
  constructor(private baggageService: BaggageService) {}

  ngOnInit(): void {
    const subscription = this.baggageService
      .getCountries()
      .subscribe((countries: Countries[]) => {
        this.countries = countries;
      });
    this.subscriptions.add(subscription);
  }

  public filterCountry(event: AutoCompleteCompleteEvent) {
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < (this.countries as any[]).length; i++) {
      let country = (this.countries as any[])[i];
      if (country.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(country);
      }
    }
    this.filteredCountries = filtered;
  }

  public selectedOrigin(): void {
    this.emitOriginCountry.emit(this.originCountry);
  }

  public selectedDestiny(): void {
    this.emitdestinateCountry.emit(this.destinateCountry);
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
