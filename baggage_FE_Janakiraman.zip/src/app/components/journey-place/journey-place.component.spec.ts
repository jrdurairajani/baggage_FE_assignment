import { ComponentFixture, TestBed } from '@angular/core/testing';
import { JourneyPlaceComponent } from './journey-place.component';
import { BaggageService } from 'src/app/services/baggage.service';
import { of } from 'rxjs';

describe('JourneyPlaceComponent', () => {
  let component: JourneyPlaceComponent;
  let fixture: ComponentFixture<JourneyPlaceComponent>;
  let baggageServiceSpy: jasmine.SpyObj<BaggageService>;

  beforeEach(async () => {
    const baggageServiceSpyObj = jasmine.createSpyObj('BaggageService', [
      'getCountries',
    ]);
    baggageServiceSpyObj.getCountries.and.returnValue(of([]));
    await TestBed.configureTestingModule({
      declarations: [JourneyPlaceComponent],
      providers: [{ provide: BaggageService, useValue: baggageServiceSpyObj }],
    }).compileComponents();
    baggageServiceSpy = TestBed.inject(
      BaggageService,
    ) as jasmine.SpyObj<BaggageService>;
    fixture = TestBed.createComponent(JourneyPlaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch countries on ngOnInit', () => {
    const countries = [
      {
        id: 1,
        name: 'India',
        country: 'IND',
      },
      {
        id: 2,
        name: 'USA',
        country: 'USA',
      },
    ];
    baggageServiceSpy.getCountries.and.returnValue(of(countries));
    component.ngOnInit();
    expect(baggageServiceSpy.getCountries).toHaveBeenCalled();
    expect(component.countries).toEqual(countries);
  });
  it('should emit origin country on selectedOrigin', () => {
    const originCountry = {
      id: 1,
      name: 'India',
      country: 'IND',
    };
    spyOn(component.emitOriginCountry, 'emit');

    component.originCountry = originCountry;
    component.selectedOrigin();

    expect(component.emitOriginCountry.emit).toHaveBeenCalledWith(
      originCountry,
    );
  });

  it('should emit destination country on selectedDestiny', () => {
    const destinateCountry = {
      id: 1,
      name: 'USA',
      country: 'USA',
    };
    spyOn(component.emitdestinateCountry, 'emit');

    component.destinateCountry = destinateCountry;
    component.selectedDestiny();

    expect(component.emitdestinateCountry.emit).toHaveBeenCalledWith(
      destinateCountry,
    );
  });
});
