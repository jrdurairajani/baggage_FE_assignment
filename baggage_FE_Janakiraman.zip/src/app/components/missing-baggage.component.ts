import { Component, OnInit } from '@angular/core';
import { BaggageService } from '../services/baggage.service';
import { Baggage, Countries } from '../models/baggage-models';

@Component({
  selector: 'app-missing-baggage',
  templateUrl: './missing-baggage.component.html',
  styleUrls: ['./missing-baggage.component.css'],
})
export class MissingBaggageComponent implements OnInit {
  public visible: boolean = false;
  public totalValue: number = 0;
  public baggageReport: any;
  public isValid: boolean = false;
  public date: string = '';
  public origin: any = '';
  public destination!: Countries;
  public baggage!: Baggage[];
  constructor(private baggageService: BaggageService) {}

  public ngOnInit(): void {}
  public receiveDate(date: string): void {
    this.date = date;
  }
  public receiveOriginCountry(originCountry: Countries): void {
    this.origin = originCountry;
  }
  public receivedestinationCountry(originDestination: Countries): void {
    this.destination = originDestination;
  }

  public receiveBaggageDetails(baggage: Baggage[]): void {
    this.baggage = baggage;
  }

  public showDialog() {
    this.visible = true;
  }

  public createBaggageReport(): any {
    return {
      date: this.date,
      origin: this.origin,
      destination: this.destination,
      baggage: this.baggage,
    };
  }

  public save(): void {
    this.baggageReport = this.createBaggageReport();
    this.totalValue = this.claimEstimation(this.baggageReport);
  }

  public claimEstimation(baggageReport: any): any {
    const totalPricePerType: any = {};
    baggageReport.baggage.forEach((item: Baggage) => {
      const key = item.name;
      totalPricePerType[key] =
        (totalPricePerType[key] || 0) + item.quantity * item.price;
    });
    let overallTotal = 0;
    Object.values(totalPricePerType).forEach((price: any) => {
      overallTotal += price;
    });
    return overallTotal;
  }
}
