import {
  Component,
  OnInit,
  OnDestroy,
  Output,
  EventEmitter,
} from '@angular/core';
import { Subscription } from 'rxjs';
import { Baggage, NumberList } from 'src/app/models/baggage-models';
import { BaggageService } from 'src/app/services/baggage.service';

@Component({
  selector: 'lost-baggage',
  templateUrl: './lost-baggage.component.html',
  styleUrls: ['./lost-baggage.component.css'],
})
export class LostBaggageComponent implements OnInit, OnDestroy {
  public selectedNumber!: number;
  private listInputs!: number;
  public items: NumberList[] = [];
  public itemValues: any[] = [];
  public itemsCheck!: boolean;
  isValid = true;
  @Output() public emitLostBaggage = new EventEmitter<any>();
  @Output() allInputsValid = new EventEmitter<boolean>();
  private subscriptions: Subscription = new Subscription();

  constructor(private baggageService: BaggageService) {}

  ngOnInit(): void {
    const subscription = this.baggageService
      .getItems()
      .subscribe((item: NumberList[]) => {
        this.items = item;
      });
    this.subscriptions.add(subscription);
  }

  selectedItem(selectedValue: NumberList) {
    this.listInputs = selectedValue.value;
    this.itemValues = [];
    for (let i = 0; i < this.listInputs; i++) {
      this.itemValues.push({
        name: '',
        quantity: '',
        price: '',
      });
    }
  }

  generateArray() {
    return Array.from({ length: this.listInputs }, (_, i) => i);
  }

  isInputInvalid(index: number): boolean {
    const item = this.itemValues[index];
    this.itemsCheck = !item.name || !item.quantity || !item.price;
    if (item.name !== '' && item.quantity !== '' && item.price !== '') {
      this.emitLostBaggage.emit(this.itemValues);
    }
    return this.itemsCheck;
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
