import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LostBaggageComponent } from './lost-baggage.component';
import { BaggageService } from 'src/app/services/baggage.service';
import { of } from 'rxjs';

describe('LostBaggageComponent', () => {
  let component: LostBaggageComponent;
  let fixture: ComponentFixture<LostBaggageComponent>;
  let baggageServiceSpy: jasmine.SpyObj<BaggageService>;

  beforeEach(async () => {
    const baggageServiceSpyObj = jasmine.createSpyObj('BaggageService', [
      'getItems',
    ]);
    baggageServiceSpyObj.getItems.and.returnValue(of([])); // Use getItems instead of getCountries
    await TestBed.configureTestingModule({
      declarations: [LostBaggageComponent],
      providers: [{ provide: BaggageService, useValue: baggageServiceSpyObj }],
    }).compileComponents();
    baggageServiceSpy = TestBed.inject(
      BaggageService,
    ) as jasmine.SpyObj<BaggageService>;
    fixture = TestBed.createComponent(LostBaggageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch items on ngOnInit', () => {
    const items = [
      { label: '1', value: 1 },
      { label: '2', value: 2 },
    ];
    baggageServiceSpy.getItems.and.returnValue(of(items));

    component.ngOnInit();

    expect(baggageServiceSpy.getItems).toHaveBeenCalled();
    expect(component.items).toEqual(items);
  });
});
