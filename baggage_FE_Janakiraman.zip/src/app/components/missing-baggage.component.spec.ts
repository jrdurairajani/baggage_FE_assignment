import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MissingBaggageComponent } from './missing-baggage.component';
import { BaggageService } from '../services/baggage.service';
import { of } from 'rxjs';

describe('MissingBaggageComponent', () => {
  let component: MissingBaggageComponent;
  let fixture: ComponentFixture<MissingBaggageComponent>;
  let baggageServiceSpy: jasmine.SpyObj<BaggageService>;

  beforeEach(async () => {
    const baggageServiceSpyObj = jasmine.createSpyObj('BaggageService', [
      'getItems',
    ]);
    baggageServiceSpyObj.getItems.and.returnValue(of([]));
    await TestBed.configureTestingModule({
      declarations: [MissingBaggageComponent],
      providers: [{ provide: BaggageService, useValue: baggageServiceSpyObj }],
    }).compileComponents();
    baggageServiceSpy = TestBed.inject(
      BaggageService,
    ) as jasmine.SpyObj<BaggageService>;
    fixture = TestBed.createComponent(MissingBaggageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should receive date', () => {
    const date = '2024-03-17';
    component.receiveDate(date);
    expect(component.date).toEqual(date);
  });

  it('should receive origin country', () => {
    const originCountry = { id: 1, name: 'USA', country: 'USA' };
    component.receiveOriginCountry(originCountry);
    expect(component.origin).toEqual(originCountry);
  });

  it('should receive destination country', () => {
    const destinationCountry = { id: 2, name: 'Canada', country: 'CA' };
    component.receivedestinationCountry(destinationCountry);
    expect(component.destination).toEqual(destinationCountry);
  });

  it('should receive baggage details', () => {
    const baggageDetails = [{ name: 'Laptop', quantity: 1, price: 1000 }];
    component.receiveBaggageDetails(baggageDetails);
    expect(component.baggage).toEqual(baggageDetails);
  });

  it('should create baggage report', () => {
    component.date = '2024-03-17';
    component.origin = { id: 1, name: 'USA', country: 'USA' };
    component.destination = { id: 2, name: 'Canada', country: 'CA' };
    component.baggage = [{ name: 'Laptop', quantity: 1, price: 1000 }];
    const expectedBaggageReport = {
      date: '2024-03-17',
      origin: { id: 1, name: 'USA', country: 'USA' },
      destination: { id: 2, name: 'Canada', country: 'CA' },
      baggage: [{ name: 'Laptop', quantity: 1, price: 1000 }],
    };
    expect(component.createBaggageReport()).toEqual(expectedBaggageReport);
  });

  it('should calculate total value', () => {
    const baggageReport = {
      date: '2024-03-17',
      origin: { id: 1, name: 'USA', country: 'USA' },
      destination: { id: 2, name: 'Canada', country: 'CA' },
      baggage: [{ name: 'Laptop', quantity: 1, price: 1000 }],
    };
    expect(component.claimEstimation(baggageReport)).toEqual(1000);
  });
});
