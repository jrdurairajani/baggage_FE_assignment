import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'journey-date',
  templateUrl: './journey-date.component.html',
  styleUrls: ['./journey-date.component.css'],
  providers: [DatePipe],
})
export class JourneyDateComponent {
  @Output() public emitSelectedDate = new EventEmitter<string>();

  public date!: Date;

  constructor(private datePipe: DatePipe) {}

  public onSelect(): void {
    const formattedDate = this.datePipe.transform(this.date, 'dd-MM-yy');
    if (formattedDate !== null) {
      this.emitSelectedDate.emit(formattedDate);
    }
  }
}
