import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { JourneyDateComponent } from './journey-date.component';
import { DatePipe } from '@angular/common';

describe('JourneyDateComponent', () => {
  let component: JourneyDateComponent;
  let fixture: ComponentFixture<JourneyDateComponent>;
  let datePipe: DatePipe;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [JourneyDateComponent],
      providers: [DatePipe],
    }).compileComponents();

    fixture = TestBed.createComponent(JourneyDateComponent);
    component = fixture.componentInstance;
    datePipe = TestBed.inject(DatePipe);
    spyOn(component.emitSelectedDate, 'emit');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit formatted date on onSelect()', () => {
    const mockDate = new Date('2024-03-17');
    component.date = mockDate;
    component.onSelect();
    const formattedDate = datePipe.transform(mockDate, 'dd-MM-yy');
    if (formattedDate !== null) {
      expect(component.emitSelectedDate.emit).toHaveBeenCalledWith(
        formattedDate,
      );
    }
  });
});
